# Omamek Platform

Instructions to deploy the app.